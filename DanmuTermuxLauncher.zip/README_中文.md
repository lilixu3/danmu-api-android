# 弹幕API启动器（Android + Termux）

这个工程把你提供的 `danmu_api_server` Node 项目打包进 Android App（作为 assets），
并通过 **Termux 的 RUN_COMMAND** 在手机上用 **Termux 的最新 Node** 来运行服务。

## 你能得到什么
- 安装 App → 打开 → 点按钮即可：
  - **初始化/更新环境**（安装 nodejs、解压项目、npm install）
  - **启动/停止服务**
- 主界面中文

## 前置要求（必须）
1. 安装 Termux。
   - Termux 现在也已回到 Google Play（一般要求 Android 11+），你从 Google Play 装的通常也可以用。
   - 但如果你装到的是“老旧 Play 商店版本”，可能会导致 pkg 更新/安装 Node 出问题；这种情况建议改用 F-Droid / GitHub 版。
2. 第一次打开一次 Termux，让它完成初始化。
3. 在 Termux 里执行（让 Termux 访问外部存储/下载目录）：
   ```bash
   termux-setup-storage
   ```
4. 允许外部 App 调用 Termux 执行命令：
   - 编辑 `~/.termux/termux.properties` 添加：
     ```
     allow-external-apps=true
     ```
   - 执行：
     ```bash
     termux-reload-settings
     ```
5. 系统设置里给本应用打开“额外权限 / Additional permissions”中的 **Run commands in Termux environment**。

## 构建 APK
用 Android Studio 打开项目根目录 `DanmuTermuxLauncher/`，等待 Gradle Sync 完成，然后 Build → Build APK。

## 运行服务
回到 App：
1) 点【① 初始化/更新环境】
2) 点【② 启动服务】

默认端口（来自项目代码）：
- HTTP API：9321
- WebSocket：5321

## 项目 zip 导出位置
App 会把项目 zip 导出到手机【下载】目录：
- /storage/emulated/0/Download/danmu_api_server.zip

Termux 里对应路径通常是：
- ~/storage/downloads/danmu_api_server.zip

## 日志位置（在 Termux 查看）
- 初始化日志：`~/danmu_android/init.log`
- 服务日志：`~/danmu_android/server.log`

