package vip.yesmail.danmu.termuxlauncher

import android.content.ContentValues
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var tvPaths: TextView
    private lateinit var tvHelp: TextView

    private val termuxPkg = "com.termux"
    private val runCommandAction = "com.termux.RUN_COMMAND"
    private val runCommandService = "com.termux.app.RunCommandService"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tvStatus)
        tvPaths = findViewById(R.id.tvPaths)
        tvHelp = findViewById(R.id.tvHelp)

        findViewById<Button>(R.id.btnInit).setOnClickListener {
            val zip = ensureProjectZip()
            val cmd = buildInitCommand(zip.absolutePath)
            runInTermux(cmd)
        }

        findViewById<Button>(R.id.btnStart).setOnClickListener {
            val cmd = buildStartCommand()
            runInTermux(cmd)
        }

        findViewById<Button>(R.id.btnStop).setOnClickListener {
            val cmd = buildStopCommand()
            runInTermux(cmd)
        }

        findViewById<Button>(R.id.btnOpenTermux).setOnClickListener {
            openTermux()
        }

        findViewById<Button>(R.id.btnCopyCmd).setOnClickListener {
            copyUsefulCommands()
        }

        refreshUi()
    }

    private fun refreshUi() {
        val termuxInstalled = isPackageInstalled(termuxPkg)
        val perm = hasTermuxRunCommandPermission()

        val status = buildString {
            append("状态：\n")
            append("- Termux 是否已安装：")
            append(if (termuxInstalled) "是" else "否")
            append("\n")
            append("- 本应用是否已获 Termux RUN_COMMAND 权限：")
            append(if (perm) "是" else "否")
            append("\n")
        }
        tvStatus.text = status

        // Android 11+ 开始，其他 App 访问 /Android/data/xxx/ 受限。
        // 所以把 zip 导出到公共下载目录，让 Termux 能直接按路径读取。
        val zipFile = File("/storage/emulated/0/Download", "danmu_api_server.zip")
        val paths = buildString {
            append("本应用外部目录：\n")
            append(getExternalFilesDir(null)?.absolutePath ?: "(未知)")
            append("\n\n")
            append("项目压缩包将导出到（公共下载目录）：\n")
            append(zipFile.absolutePath)
            append("\n（Termux 对应：~/storage/downloads/danmu_api_server.zip）")
            append("\n\n")
            append("Termux 内部目录（启动脚本会用到）：\n")
            append("~/danmu_android/project/app\n")
            append("日志：~/danmu_android/init.log 和 ~/danmu_android/server.log\n")
        }
        tvPaths.text = paths

        tvHelp.text = buildHelpText()
    }

    private fun buildHelpText(): String {
        return """
1) 先装 Termux
   - 现在 Termux 也已回到 Google Play（一般要求 Android 11+）。
   - 如果你这台手机装到的是“老旧 Play 商店版本”，可能会导致 pkg 更新/安装 Node 出问题；这种情况建议改用 F-Droid / GitHub 版。

2) 第一次必须打开一次 Termux，让它完成初始化。

3) 让 Termux 能访问外部存储（否则无法读取本应用复制出来的 project zip）：
   - 在 Termux 里执行：termux-setup-storage
   - 然后在系统设置里授予 Termux 的“文件/媒体”权限（不同系统叫法略有差异）。

4) 让本应用能调用 Termux 执行命令（RUN_COMMAND）：
   - Termux 需开启 allow-external-apps：
     打开 Termux → 编辑 ~/.termux/termux.properties，加入：allow-external-apps=true
     然后在 Termux 里执行：termux-reload-settings
   - 系统设置 → 本应用 → 额外权限（Additional permissions）→ 打开 “Run commands in Termux environment”（不同机型文案略有差异）

5) 回到本应用：
   - 点【① 初始化/更新环境】（会在 Termux 里安装 nodejs/unzip，并解压项目、npm install）
   - 点【② 启动服务】

6) 端口说明（来自你项目默认配置）：
   - HTTP API：9321
   - WebSocket：5321

7) 查看日志：点【打开 Termux 查看日志】，然后执行：
   - tail -n 200 ~/danmu_android/init.log
   - tail -n 200 ~/danmu_android/server.log

提示：
- 这是“Termux 托管 Node 服务”的方案：Node 版本、依赖都跟着 Termux 仓库尽量走新。
- 如果你想要“完全不依赖 Termux 的内嵌 Node”版本，也可以做，但 Node 版本通常没 Termux 新。
""".trimIndent()
    }

    private fun ensureProjectZip(): File {
        // 固定导出到 Download 目录，保证 Termux 可读（路径稳定，命令里直接用绝对路径）。
        val dest = File("/storage/emulated/0/Download", "danmu_api_server.zip")
        if (dest.exists() && dest.length() > 0) return dest

        // Android 10+ 使用 MediaStore 写入 Download（不需要传统存储权限）。
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, "danmu_api_server.zip")
                put(MediaStore.Downloads.MIME_TYPE, "application/zip")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                put(MediaStore.Downloads.IS_PENDING, 1)
            }

            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("无法写入下载目录（MediaStore insert 失败）")

            resolver.openOutputStream(uri).use { out ->
                requireNotNull(out) { "无法打开下载目录输出流" }
                assets.open("danmu_api_server.zip").use { input ->
                    input.copyTo(out)
                }
            }

            val done = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
            resolver.update(uri, done, null, null)

            // 约定的路径：/storage/emulated/0/Download/danmu_api_server.zip
            return dest
        }

        // Android 9 及以下：直接写入 Download（需要系统允许传统写入；minSdk=26 已较新，通常可用）。
        assets.open("danmu_api_server.zip").use { input ->
            FileOutputStream(dest).use { output ->
                input.copyTo(output)
            }
        }
        return dest
    }

    private fun buildInitCommand(zipPath: String): String {
        // 注意：命令会在 Termux 里执行。
        // 1) 更新包
        // 2) 安装 nodejs/unzip
        // 3) 解压项目并 npm install
        val escapedZip = zipPath.replace("\"", "\\\"")
        return """
set -e
mkdir -p "$HOME/danmu_android"
LOG="$HOME/danmu_android/init.log"
exec >"$LOG" 2>&1

echo "[init] $(date)"

# 更新 Termux 包列表（可能耗时）
pkg update -y
pkg upgrade -y || true

# 安装尽量新的 Node
pkg install -y nodejs unzip

BASE="$HOME/danmu_android/project"
rm -rf "$BASE"
mkdir -p "$BASE"

echo "[init] unzip project from: $escapedZip"
unzip -o "$escapedZip" -d "$BASE"

cd "$BASE/app"
node -v
npm -v

# 安装依赖（按 package-lock.json / package.json 来）
npm install --no-fund --no-audit

# 尽量升级到 semver 允许的最新依赖（不会自动跨大版本）
npm update --no-fund --no-audit || true

echo "[init] done"
""".trimIndent()
    }

    private fun buildStartCommand(): String {
        return """
set -e
mkdir -p "$HOME/danmu_android"
LOG="$HOME/danmu_android/server.log"
PID="$HOME/danmu_android/server.pid"
BASE="$HOME/danmu_android/project/app"

exec >>"$LOG" 2>&1

echo "[start] $(date)"
cd "$BASE"

if [ -f "$PID" ]; then
  OLD_PID=$(cat "$PID" || true)
  if [ -n "$OLD_PID" ] && kill -0 "$OLD_PID" 2>/dev/null; then
    echo "[start] already running: $OLD_PID"
    exit 0
  fi
  rm -f "$PID"
fi

nohup node danmu_api/server.js >>"$LOG" 2>&1 &
echo $! > "$PID"
echo "[start] started pid: $(cat "$PID")"
""".trimIndent()
    }

    private fun buildStopCommand(): String {
        return """
set -e
PID="$HOME/danmu_android/server.pid"
LOG="$HOME/danmu_android/server.log"

exec >>"$LOG" 2>&1

echo "[stop] $(date)"

if [ ! -f "$PID" ]; then
  echo "[stop] pid file not found"
  exit 0
fi

P=$(cat "$PID" || true)
if [ -z "$P" ]; then
  echo "[stop] empty pid"
  rm -f "$PID"
  exit 0
fi

if kill -0 "$P" 2>/dev/null; then
  kill "$P"
  echo "[stop] killed $P"
else
  echo "[stop] process not running: $P"
fi

rm -f "$PID"
""".trimIndent()
    }

    private fun runInTermux(shellCommand: String) {
        if (!isPackageInstalled(termuxPkg)) {
            showDialog(
                title = "未安装 Termux",
                message = "检测到你还没安装 Termux。\n\n请先安装新版 Termux（推荐 F-Droid / GitHub 版），然后再回来点按钮。"
            )
            return
        }

        if (!hasTermuxRunCommandPermission()) {
            showDialog(
                title = "缺少 Termux RUN_COMMAND 权限",
                message = "系统还没授予本应用调用 Termux 执行命令的权限。\n\n请按页面下方说明先在 Termux 开启 allow-external-apps，并在系统设置里给本应用开启“额外权限”。"
            )
            return
        }

        val intent = Intent(runCommandAction).apply {
            setClassName(termuxPkg, runCommandService)
            putExtra("com.termux.RUN_COMMAND_PATH", "\$PREFIX/bin/bash")
            putExtra("com.termux.RUN_COMMAND_ARGUMENTS", arrayOf("-lc", shellCommand))
            putExtra("com.termux.RUN_COMMAND_WORKDIR", "~")
            putExtra("com.termux.RUN_COMMAND_BACKGROUND", true)
        }

        try {
            startService(intent)
            Toast.makeText(this, "已向 Termux 发送命令（后台执行）。可到 Termux 查看日志。", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            showDialog(
                title = "启动 Termux 命令失败",
                message = "错误：${e.message}\n\n可能原因：\n- Termux 没有开启 allow-external-apps\n- 系统没授予本应用“Run commands in Termux environment”\n- Termux 版本过旧\n\n建议先打开 Termux 手动执行：termux-setup-storage，然后再试。"
            )
        }
    }

    private fun openTermux() {
        val launch = packageManager.getLaunchIntentForPackage(termuxPkg)
        if (launch == null) {
            Toast.makeText(this, "找不到 Termux（可能未安装）", Toast.LENGTH_SHORT).show()
            return
        }
        startActivity(launch)
    }

    private fun copyUsefulCommands() {
        val text = """
# 初始化日志
cat ~/danmu_android/init.log

tail -n 200 ~/danmu_android/init.log

# 服务日志
cat ~/danmu_android/server.log

tail -n 200 ~/danmu_android/server.log

# 看服务是否在跑
cat ~/danmu_android/server.pid

ps -A | grep -i node
""".trimIndent()

        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("termux_cmd", text))
        Toast.makeText(this, "已复制到剪贴板", Toast.LENGTH_SHORT).show()
    }

    private fun hasTermuxRunCommandPermission(): Boolean {
        return checkSelfPermission("com.termux.permission.RUN_COMMAND") == PackageManager.PERMISSION_GRANTED
    }

    private fun isPackageInstalled(pkg: String): Boolean {
        return try {
            packageManager.getPackageInfo(pkg, 0)
            true
        } catch (_: PackageManager.NameNotFoundException) {
            false
        }
    }

    private fun showDialog(title: String, message: String) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("确定", null)
            .show()
    }
}
