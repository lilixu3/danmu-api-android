package com.example.danmuapiapp

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AlertDialog
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

object UpdateChecker {

    private const val LATEST_RELEASE_API = "https://api.github.com/repos/lilixu3/Private/releases/latest"
    private const val FALLBACK_LATEST_PAGE = "https://github.com/lilixu3/Private/releases/latest"

    private val executor = Executors.newSingleThreadExecutor()

    fun check(activity: Activity) {
        val currentVersion = (BuildConfig.VERSION_NAME ?: "").trim()
        if (currentVersion.isEmpty()) return

        executor.execute {
            try {
                val url = URL(LATEST_RELEASE_API)
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    connectTimeout = 8000
                    readTimeout = 8000
                    requestMethod = "GET"
                    setRequestProperty("Accept", "application/vnd.github+json")
                    // GitHub API 建议带 User-Agent
                    setRequestProperty("User-Agent", "DanmuApiApp")
                }

                val code = conn.responseCode
                if (code !in 200..299) return@execute

                val body = conn.inputStream.bufferedReader().use { it.readText() }
                val json = JSONObject(body)
                val tagName = json.optString("tag_name", "").trim()
                if (tagName.isEmpty()) return@execute

                val latestVersion = tagName.removePrefix("v").removePrefix("V").trim()
                if (!isNewerVersion(latestVersion, currentVersion)) return@execute

                val htmlUrl = json.optString("html_url", FALLBACK_LATEST_PAGE).ifBlank { FALLBACK_LATEST_PAGE }

                Handler(Looper.getMainLooper()).post {
                    if (activity.isFinishing) return@post
                    AlertDialog.Builder(activity)
                        .setTitle("发现新版本")
                        .setMessage("当前版本：$currentVersion\n最新版本：$latestVersion\n\n前往下载更新？")
                        .setPositiveButton("去更新") { _, _ ->
                            activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(htmlUrl)))
                        }
                        .setNegativeButton("取消", null)
                        .show()
                }
            } catch (_: Exception) {
                // 忽略网络/解析错误，避免影响主流程
            }
        }
    }

    private fun isNewerVersion(latest: String, current: String): Boolean {
        val l = normalize(latest)
        val c = normalize(current)
        if (l.isEmpty() || c.isEmpty()) return false

        val max = maxOf(l.size, c.size)
        for (i in 0 until max) {
            val lv = l.getOrElse(i) { 0 }
            val cv = c.getOrElse(i) { 0 }
            if (lv != cv) return lv > cv
        }
        return false
    }

    private fun normalize(v: String): List<Int> {
        // 只取数字段：比如 1.2.3-beta -> [1,2,3]
        val main = v.trim().split("-", limit = 2).firstOrNull().orEmpty()
        if (main.isBlank()) return emptyList()
        return main.split(".")
            .mapNotNull { part -> part.toIntOrNull() ?: part.filter { it.isDigit() }.toIntOrNull() }
    }
}
