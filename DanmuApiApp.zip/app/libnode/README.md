# libnode (nodejs-mobile) 放置位置

这个项目使用 Node.js Mobile (libnode.so) 来在 **无 root / 无 Magisk** 的情况下运行你的 `danmu_api` 服务器。

你需要从 nodejs-mobile 的 core library release 下载 Android 版本的 zip 包，然后把里面的内容复制到下面两个目录：

- `app/libnode/include/`  ← 复制 zip 里的 `include/`（最终会有 `app/libnode/include/node/node.h`）
- `app/libnode/bin/`      ← 复制 zip 里的 `bin/`（最终会有 `app/libnode/bin/arm64-v8a/libnode.so` 等）

参考官方文档（Android Getting started / Copy libnode headers / Copy the library files）。
