package com.example.danmuapi

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.Process
import android.system.Os
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import android.content.pm.ServiceInfo

import java.io.File

class DanmuNodeService : Service() {

    // Native entrypoint (libnode)
    external fun startNodeWithArguments(args: Array<String>): Int

    @Volatile private var started = false

    override fun onCreate() {
        super.onCreate()
        System.loadLibrary("native-lib")
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
                stopSelf()
                // Node runs inside this process, easiest reliable stop is to kill the service process.
                Process.killProcess(Process.myPid())
                return START_NOT_STICKY
            }
            ACTION_START, null -> {
                if (!started) {
                    started = true
                    startAsForeground("Running")
                    Thread {
                        try {
                            startNode()
                        } catch (t: Throwable) {
                            t.printStackTrace()
                            // If node crashed, stop and let user re-enable
                            stopSelf()
                            Process.killProcess(Process.myPid())
                        }
                    }.start()
                } else {
                    startAsForeground("Running")
                }
                return START_STICKY
            }
            else -> return START_STICKY
        }
    }

    private fun startAsForeground(text: String) {
    val notification = buildNotification(text)
    if (android.os.Build.VERSION.SDK_INT >= 29) {
        ServiceCompat.startForeground(
            this,
            NOTI_ID,
            notification,
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        )
    } else {
        startForeground(NOTI_ID, notification)
    }
}

private fun startNode() {
        // Where we keep persistent config/logs for danmu_api
        val homeDir = File(filesDir, "danmu_api_home").apply { mkdirs() }
        File(homeDir, "config").mkdirs()
        File(homeDir, "logs").mkdirs()

        // Copy JS project to filesDir (node can't execute directly from APK)
        val nodeProjectDir = File(filesDir, "nodejs-project")
        AssetCopier.copyAssetFolder(assets, "nodejs-project", nodeProjectDir)

        // Make sure ESM works as expected (treat .js as module)
        // We'll overwrite package.json inside the copied project to include "type":"module"
        PackagePatcher.ensureTypeModule(File(nodeProjectDir, "package.json"))

        // Set env vars visible to libnode
        Os.setenv("DANMU_API_HOME", homeDir.absolutePath, true)
        Os.setenv("NODE_ENV", "production", true)

        // Start node
        val entry = File(nodeProjectDir, "android-server.mjs").absolutePath
        startNodeWithArguments(arrayOf("node", entry))
    }

    private fun buildNotification(text: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Danmu API Server")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setOngoing(true)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Danmu API background service",
                NotificationManager.IMPORTANCE_LOW
            )
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.example.danmuapi.action.START"
        const val ACTION_STOP = "com.example.danmuapi.action.STOP"
        private const val CHANNEL_ID = "danmu_api_channel"
        private const val NOTI_ID = 9321
    }
}
