package com.example.danmuapi

import android.content.res.AssetManager
import java.io.File
import java.io.FileOutputStream

object AssetCopier {

    fun copyAssetFolder(assetManager: AssetManager, fromAssetPath: String, toDir: File) {
        val files = assetManager.list(fromAssetPath) ?: emptyArray()
        if (files.isEmpty()) {
            copyAsset(assetManager, fromAssetPath, toDir)
            return
        }
        if (!toDir.exists()) toDir.mkdirs()
        for (f in files) {
            val subFrom = "$fromAssetPath/$f"
            val subTo = File(toDir, f)
            val subFiles = assetManager.list(subFrom) ?: emptyArray()
            if (subFiles.isEmpty()) {
                copyAsset(assetManager, subFrom, subTo)
            } else {
                copyAssetFolder(assetManager, subFrom, subTo)
            }
        }
    }

    private fun copyAsset(assetManager: AssetManager, fromAssetPath: String, toFile: File) {
        // Overwrite on every start to keep simple. If you want speed, add APK version checks.
        toFile.parentFile?.mkdirs()
        assetManager.open(fromAssetPath).use { input ->
            FileOutputStream(toFile, false).use { output ->
                input.copyTo(output)
            }
        }
    }
}
