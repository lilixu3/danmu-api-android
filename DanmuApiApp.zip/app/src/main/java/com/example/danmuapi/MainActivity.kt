package com.example.danmuapi

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.Switch
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private lateinit var toggleSwitch: Switch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ensureNotificationPermission()

        statusText = findViewById(R.id.statusText)
        toggleSwitch = findViewById(R.id.toggleSwitch)

        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val enabled = prefs.getBoolean(KEY_ENABLED, false)
        toggleSwitch.isChecked = enabled
        renderStatus(enabled)

        toggleSwitch.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean(KEY_ENABLED, isChecked).apply()
            if (isChecked) {
                val i = Intent(this, DanmuNodeService::class.java).apply {
                    action = DanmuNodeService.ACTION_START
                }
                ContextCompat.startForegroundService(this, i)
            } else {
                val i = Intent(this, DanmuNodeService::class.java).apply {
                    action = DanmuNodeService.ACTION_STOP
                }
                startService(i)
            }
            renderStatus(isChecked)
        }

        findViewById<Button>(R.id.openMainBtn).setOnClickListener {
            val uri = Uri.parse("http://127.0.0.1:9321")
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        }
    }

    private fun ensureNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            val granted = ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    1001
                )
            }
        }
    }

    private fun renderStatus(enabled: Boolean) {
        statusText.text = if (enabled) "Status: running (foreground service)" else "Status: stopped"
    }

    companion object {
        const val PREFS = "danmu_prefs"
        const val KEY_ENABLED = "enabled"
    }
}
