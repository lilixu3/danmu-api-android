package com.example.danmuapi

import org.json.JSONObject
import java.io.File

object PackagePatcher {
    fun ensureTypeModule(packageJson: File) {
        if (!packageJson.exists()) return
        val text = packageJson.readText(Charsets.UTF_8)
        val json = try { JSONObject(text) } catch (_: Throwable) { return }
        if (!json.has("type")) {
            json.put("type", "module")
            packageJson.writeText(json.toString(2), Charsets.UTF_8)
        }
    }
}
