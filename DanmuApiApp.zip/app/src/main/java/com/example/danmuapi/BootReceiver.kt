package com.example.danmuapi

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return

        val prefs = context.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)
        val enabled = prefs.getBoolean(MainActivity.KEY_ENABLED, false)
        if (enabled) {
            val i = Intent(context, DanmuNodeService::class.java).apply {
                action = DanmuNodeService.ACTION_START
            }
            ContextCompat.startForegroundService(context, i)
        }
    }
}
