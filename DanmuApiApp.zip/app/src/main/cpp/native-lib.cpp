#include <jni.h>
#include <string>
#include <vector>
#include <android/log.h>
#include "node.h"

#define LOG_TAG "DanmuApi"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// Start Node.js with arguments passed from Kotlin.
// This follows the Node.js Mobile docs example.
extern "C"
JNIEXPORT jint JNICALL
Java_com_example_danmuapi_DanmuNodeService_startNodeWithArguments(
        JNIEnv *env,
        jobject /* this */,
        jobjectArray arguments) {

    int argc = env->GetArrayLength(arguments);
    std::vector<std::string> argv_strings;
    argv_strings.reserve(argc);

    for (int i = 0; i < argc; i++) {
        jstring arg = (jstring) env->GetObjectArrayElement(arguments, i);
        const char *arg_chars = env->GetStringUTFChars(arg, nullptr);
        argv_strings.emplace_back(arg_chars);
        env->ReleaseStringUTFChars(arg, arg_chars);
        env->DeleteLocalRef(arg);
    }

    // node::Start expects a mutable char** on Node 18+, even though it doesn't mutate our strings.
    // Build a char* argv array by casting each c_str() pointer.
    std::vector<char*> argv;
    argv.reserve(argc);
    for (auto &s : argv_strings) {
        argv.push_back(const_cast<char*>(s.c_str()));
    }

    LOGI("Starting node with %d args. Entry: %s", argc, argc >= 2 ? argv[1] : "(none)");
    return node::Start(argc, argv.data());
}
