# Build & Install

1. Open this project in Android Studio.
2. Download Node.js Mobile (nodejs-mobile) **core library** Android zip from the releases page:
   https://github.com/nodejs-mobile/nodejs-mobile/releases
3. Copy from the zip:
   - `include/` -> `app/libnode/include/`
   - `bin/` -> `app/libnode/bin/`
4. Sync Gradle, then Run on device.

## Usage

- Open app -> toggle "Enable background service".
- A foreground notification will appear; keep it to allow background running.
- API ports: 9321 (main), 5321 (proxy).

## Notes

- Persistent config/logs are stored at: app internal storage `files/danmu_api_home/`
- Node project is copied to `files/nodejs-project/` each start.
